THANKS FOR DOWNLOAD AND PLAYING THIS GAME !

Movement :
W / UP Arrow      : Go Forward
S / DOWN Arrow : Go Backward
A / LEFT Arrow    : Go Left
D / RIGHT Arrow  : Go Right
R                        : Recoil bullets

Use Mouse and Keyboard to play !

Mouse button:
LEFT Click                  : Shoot
RIGHT / MIDDLE Click : None

--------------------------------------------------------------------------------------------------
Contact:
Email : superzeldalink@gmail.com
Facebook : facebook.com/superzeldalink.link
